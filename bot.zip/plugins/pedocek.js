let handler  = async (m, { conn }) => {
  conn.reply(m.chat,`“${pickRandom(global.Pedo)}”`, m)
}
handler.help = ['pedocek']
handler.tags = ['fun']
handler.command = /^(Pedocek)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.diamond = true

export default handler 

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

global.Pedo = [
'Pedo Level : 4%\n\nAMAN BANGET!',
'Pedo Level : 7%\n\nMasih Aman',
'Pedo Level : 12%\n\nAman Kok',
'Pedo Level : 22%\n\nHampir Aman',
'Pedo Level : 27%\n\nPedo dikit',
'Pedo Level : 35%\n\nPedo ¼',
'Pedo Level : 41%\n\nDah lewat dri Aman',
'Pedo Level : 48%\n\nSetengah Pedo',
'Pedo Level : 56%\n\nLu Pedo juga',
'Pedo Level : 64%\n\numayan Pedo',
'Pedo Level : 71%\n\nHebatnya kePedoan lu',
'Pedo Level : 1%\n\n99% LU GAK Pedo!',
'Pedo Level : 77%\n\nGak akan Salah Lagi dah Pedonya lu',
'Pedo Level : 83%\n\nDijamin Pedo nya!',
'Pedo Level : 89%\n\nPedo Banget!',
'Pedo Level : 94%\n\nTOBAT WOEE,, Pedo LU UDH MELEWATI BATAS!😂',
'Pedo Level : 100%\n\nLU ORANG TERPEDO YANG PERNAH ADA!!!',
'Pedo Level : 100%\n\nLU ORANG TERPEDO YANG PERNAH ADA!!!',
'Pedo Level : 100%\n\nLU ORANG TERPEDO YANG PERNAH ADA!!!',
'Pedo Level : 100%\n\nLU ORANG TERPEDO YANG PERNAH ADA!!!',
]